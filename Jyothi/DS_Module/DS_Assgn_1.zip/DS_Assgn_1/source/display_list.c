#include "header.h"

M_NODE *display_list(M_NODE *m_head, int count)
{
	if(m_head == NULL){
		perror("no such list");

		return NULL;
	}

	M_NODE *temp = m_head;
	int list = 1;

	while(--count){
		printf("%d. List%d\n", list, list);
		list++;
	}
	
	char *input = NULL;

	input = allocate_space(input);

	list = my_atoi(read_input(input));
	validate_int(list);

	temp = m_head;

	while(--list)
		temp = temp -> m_rlink;

	if(NULL == (temp -> m_node = create_list(temp -> m_node))){
		return NULL;
	}

	return m_head;
}
