#include "header.h"

int main(void)
{
	M_NODE *m_head = NULL;
	char *input = NULL;
	int count = 0;

	input = allocate_space(input);

	while(1){
		
		printf("1. create new list\n"
				"2. use existing list\n"
				"3. search element list\n"
				"4. display\n"
				"5. exit\n"
				"enter your choice:\n");
		
		int choice = my_atoi(read_input(input));
		validate_int(choice);
		
		switch(choice){
			
			case 1: if(NULL == (m_head = insert_master_node(m_head))){
						perror("list creation failed");

						break;
					}

					printf("list creation successfull\n");
					
					count++;

					break;
			
			case 2:	if(NULL == (m_head = display_list(m_head,count))){
						perror("no such list");

						break;
					}

					count++;

					break;

			case 3:

			case 4:	printf("Displaying contents..\n");
					m_display(m_head);
					break;

			case 5:	free(input);
					exit(EXIT_SUCCESS);

			default:printf("invalid choice\n");
		}
	}
}
