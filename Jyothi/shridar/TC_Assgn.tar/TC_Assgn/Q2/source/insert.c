#include "header.h"

void appendNode ( SLL **head, SLL **new)
{
	SLL *cur = NULL;
	cur = *head;
	
	if(emptyList(cur))
	{
		*head = *new;
		return;
	}
	else
	{
		while(cur -> link != NULL)
			cur = cur -> link;
	
		cur -> link = *new;
	}
}

void insertNode (SLL **head, SLL **new)
{
		(*new) -> link = *head;
		*head = *new;
}

void insertNodePos (SLL **head, SLL **new, int pos)
{
    SLL *cur = NULL;
	cur = *head;
	
	int count = 0;
	count = numNodes(head);
	printf("begin\n");
	if(count == 0 || pos == 1)
	{
		printf("middle\n");
		(*new) -> link = cur;
		*head = *new;
		return;
	}
	printf("end\n");

	if(pos > count + 1)
	{
		printf("Invalid position\n");
		return;
	}
    else
    {
		pos--;
		while(--pos)
			cur= cur -> link;

		(*new) -> link = cur -> link;
		cur -> link = (*new);
	}
}
