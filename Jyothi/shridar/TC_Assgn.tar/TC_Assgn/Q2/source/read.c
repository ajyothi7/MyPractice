#include "header.h"

int readnum()
{
	char *ptr = NULL;
	
	if(NULL == (ptr = (char *)malloc(sizeof(char) * MAX)))
	{
		perror("i/p failed\n");
        exit(EXIT_FAILURE);
	}
	
	if(NULL == fgets(ptr,MAX,stdin))
	{
		perror("i/p failed\n");
		exit(EXIT_FAILURE);
	}
	
	return (atoi(ptr));
}

