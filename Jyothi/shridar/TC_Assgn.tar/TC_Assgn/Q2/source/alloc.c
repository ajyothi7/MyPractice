#include "header.h"

SLL * allocateNode (void *data)
{
	SLL * ptr = NULL;
	if(NULL == (ptr = (SLL *)malloc(sizeof(SLL)))){
		perror("Malloc failed\n");
		exit(EXIT_FAILURE);
	}
	ptr -> dat = data;
	ptr -> link = NULL;
	return ptr;
}
