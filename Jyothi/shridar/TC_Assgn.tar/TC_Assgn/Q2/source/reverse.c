#include "header.h"

SLL * reverseList (SLL *list)
{
	SLL *prev = NULL;
	SLL *cur = NULL;
	SLL *next = NULL;
	
	if(list == NULL)
	{
		printf("empty list\n");
		return list;
	}

	if(list -> link == NULL)
		return list;

	cur = list -> link;
	next = cur;
	prev = list;

	while(cur != NULL)
	{
		cur = cur -> link;
		next -> link = prev;
		prev = next;
		next = cur;
	}

	list -> link = NULL;
	list = prev;

	return list;
}

