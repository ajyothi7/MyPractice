#include "header.h"

SLL * sortList (SLL *list)
{
	SLL *cur = NULL;
	SLL *prev = NULL;
	int n = 0;
	int * temp = NULL;
	int i;
	int j;

	n = numNodes (&list); 
	printf("%d\n",n);
	for(i = 0; i < n; i++)
	{
		prev = list;
		cur = list -> link;
		for(j = 0; j < n - i - 1;j++)
		{
			if(*(int *)(prev -> dat) > *(int *)(cur -> dat))
			{
				temp = (int *)(prev -> dat);
				prev -> dat = cur -> dat;
				cur -> dat = (void *)temp;
			}
			prev = cur;
			cur = cur -> link;
		}
	}
	return list;
}
