#include "header.h"

void initlist ( SLL **list)
{
	*list = NULL;
	return;
}

int emptyList (SLL *list)
{
	if(list == NULL)
		return 1;
	else
		return 0;
}

int numNodes (SLL **head)
{
	SLL *cur = NULL;
	cur = *head;
	int count = 0;
	
	while(cur != NULL)
	{
		cur = cur -> link;
		count++;
	}
	return count;
}

SLL *getNthNode (SLL *head, int n)
{
	SLL *cur = NULL;
	
	if(emptyList(head)){
		printf("Empty list\n");
		return NULL;
	}
	else if(n == 0)
    {
        return head;
    }
	else if(n == 1)
	{
		return NULL;
	}
	else{
		cur = head;
		while(--n)
			cur = cur -> link;
	
		printf("%d\n",*(int *)cur -> dat);	
		return cur;
	}
}
