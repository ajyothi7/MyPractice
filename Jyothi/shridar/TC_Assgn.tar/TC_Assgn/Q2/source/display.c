#include "header.h"

void display(SLL *head)
{
	if(emptyList(head))
	{
		printf("LIST is empty\n");
		return;
	}
	else
	{
		while(head != NULL)
		{
			printf("%d\t",*(int *)(head -> dat));
			head = head -> link;
		}
		printf("\n");
	}
}
