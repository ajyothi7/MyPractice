#include "header.h"

void delNode (SLL **head, SLL *node)
{
	SLL *cur = NULL;

	if(emptyList(*head))
    {
        printf("can't delete\n");
        return;
    }
	if(node == (*head))
	{
	cur = node;
	(*head) = cur -> link;
	}
	else if (node == NULL)
	{
	cur = (*head) -> link;
	(*head) -> link = cur -> link;
	}
	else
	{
	cur = node -> link;
	node -> link = node -> link -> link;
	}
	destroyNode(head,cur,&(freeNode));
}

void freeNode (void **list)
{
	SLL *cur = NULL;
	cur = *list;
	free(cur);
}

void destroyNode (SLL **head, SLL *node, void (*freeFunc)(void **))
{
//	freeFunc = freeNode;
	void ** ptr = NULL;	
	ptr = (void **)&node;
	freeFunc(ptr);
	return;
}
