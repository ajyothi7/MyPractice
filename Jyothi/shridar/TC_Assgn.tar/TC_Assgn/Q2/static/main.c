#include <header.h>

int main(void)
{
	int ch;
	int n;
	int cnt;
	int *info = NULL;
	char *ptr = NULL;
	int pos = 0;
	SLL *node = NULL;
	SLL *np = NULL;
	SLL *head;
	
	initlist(&head);
	
	ptr = (char *)malloc(sizeof(char) * MAX);

	while(1)
	{
		printf(	"1.Insert at begining\n"	
				"2.Reverse\n"
				"3.Display\n"
				"4.Sort\n"
				"5.Insert at end\n"
				"6.Insert @ pos\n"
				"7.Delete\n"
				"0.exit\n");
		ch = readnum();
		switch(ch)
		{
			case 0 :	exit(0);
						break;

			case 1 :	info = (int *)malloc(sizeof(int));
						printf("Enter the item\n");
						fgets(ptr,MAX,stdin);
						*info = (atoi(ptr));
						np = allocateNode(info);
						insertNode(&head,&np);
						info = NULL;
						break;
			case 2 :	head = reverseList(head);
						break;
			case 3 :	display(head);
						break;		
			case 4 :	head = sortList(head);
						break;
			case 5 :	info = (int *)malloc(sizeof(int));
                        printf("Enter the item\n");
                        fgets(ptr,MAX,stdin);
                        *info = (atoi(ptr));
                        np = allocateNode(info);
                        appendNode(&head,&np);
                        info = NULL;
                        break;
			case 6 :	info = (int *)malloc(sizeof(int));
                        printf("Enter the item\n");
                        fgets(ptr,MAX,stdin);
                        *info = (atoi(ptr));
						printf("Enter the pos\n");
                        fgets(ptr,MAX,stdin);
						pos = atoi(ptr);
                        np = allocateNode(info);
                        insertNodePos(&head,&np,pos);
                        info = NULL;
                        break;	
			case 7 :	printf("enter the node number to be deleted\n");
						fgets(ptr,MAX,stdin);
						n = atoi(ptr);
						cnt = numNodes(&head);
						if( n <= 0 || n > cnt)
						{
						printf("Invalid no\n");
						break;
						}
						n--;
						node = getNthNode(head,(n));
						delNode(&head,node);
						break;
		}
	}
	return 0;
}
