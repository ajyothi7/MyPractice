#include <stdio.h>
#include <stdlib.h>

#define MAX 256

typedef struct node{
	void * dat;
	struct node *link;
	}SLL;

SLL * allocateNode (void *);

void display(SLL *);

void initlist ( SLL **);

int emptyList (SLL *);

int numNodes (SLL **);

SLL *getNthNode (SLL *, int);

void insertNode (SLL **, SLL **);

void appendNode ( SLL **, SLL **);

void insertNodePos (SLL **, SLL **, int);

int readnum(void);

SLL * reverseList(SLL *);

SLL * sortList (SLL *);

void freeNode (void **);

void delNode (SLL **, SLL *);

void destroyNode (SLL **, SLL *, void (*freeFunc)(void **));


