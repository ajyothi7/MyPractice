#include <stdio.h>
#include <stdlib.h>

#define MAX 256

struct node{
	int data;
	int prio;
	struct node *link;
};

struct node * pri_insert(struct node *,int,int);

struct node * create_node(int,int);

void sort_que(struct node *);

void swap(struct node *, struct node *);

void pri_display(struct node *);

int my_atoi(char *);

struct node * pri_delete(struct node*);

struct node * pri_terminate(struct node*);

void pri_search(struct node *,int);

