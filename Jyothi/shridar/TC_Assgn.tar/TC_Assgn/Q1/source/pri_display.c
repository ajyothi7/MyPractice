#include "myheader.h"

void pri_display(struct node *rear)
{
	struct node *nodeptr = NULL;

	if(rear == NULL){
		printf("Empty list\n");
		return;
	}


	nodeptr = rear;
	printf("List is:");
	while(nodeptr->link != rear){
		 nodeptr = nodeptr->link;

		printf("%d:%d\t",nodeptr->data,nodeptr->prio);
	}
	
	nodeptr = nodeptr->link;
	printf("%d:%d\n",nodeptr->data,nodeptr->prio);
	return;
}
