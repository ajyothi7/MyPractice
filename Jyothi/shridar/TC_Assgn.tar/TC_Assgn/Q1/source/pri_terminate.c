#include "myheader.h"

struct node * pri_terminate(struct node *rear)
{
	struct node *nodeptr = NULL;
	struct node *delptr = NULL;

	if(rear == NULL){
		printf("Empty list\n");
		return rear;
	}


	nodeptr = rear;
	while(nodeptr->link != rear){
		nodeptr = nodeptr->link;
		delptr = nodeptr;
		free(delptr);
	}
	
	nodeptr = nodeptr->link;
	delptr = nodeptr;
	free(delptr);
	
	rear = NULL;
	
	return rear;
}
