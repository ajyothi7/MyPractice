#include "myheader.h"

void sort_que(struct node *rear)
{
    int swapped;
    struct node *ptr1;
	struct node *lptr = rear->link;

    if (rear-> link == rear)
        return;
 
    do
    {
        swapped = 0;
        ptr1 = rear->link;
 
        while (ptr1 -> link != lptr)
        {
            if ((ptr1->prio) < (ptr1->link->prio))
            { 
                swap(ptr1, ptr1->link);
                swapped = 1;
            }
            ptr1 = ptr1->link;
        }
        lptr = ptr1;
    }
    while (swapped);
}
 

void swap(struct node *a, struct node *b)
{	
	int temp1 = a -> prio;
    int temp2 = a -> data;
    a -> data = b -> data;
	a -> prio = b -> prio;
	b -> prio = temp1;
	b -> data = temp2;
}


