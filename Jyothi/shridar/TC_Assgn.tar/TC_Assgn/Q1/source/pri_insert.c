#include "myheader.h"

struct node * pri_insert(struct node *rear,int pri,int info)
{
//	struct node *cur = NULL;
	struct node *newnode = NULL;
	
//	cur = rear;
	newnode = create_node(pri,info);
	
	if(rear == NULL){
		rear = newnode;
		rear -> link = rear;
	}
	else{
		newnode -> link = rear -> link;
		rear -> link = newnode;
		rear = newnode;
	}

return rear;
}

