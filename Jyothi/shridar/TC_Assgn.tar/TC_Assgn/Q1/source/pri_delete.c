#include "myheader.h"

struct node * pri_delete(struct node* rear)
{
	struct node *delptr;
	if(rear == NULL){
		printf("queue is empty\n");
		return rear;
	}
	printf("deleted element is:%d\n",rear->link->data);
	delptr = rear->link;
	
	if(rear -> link == rear){
			rear = NULL;
	}
	else{
		rear -> link = rear ->link -> link;
	}
	
	free(delptr);

	return rear;
}
