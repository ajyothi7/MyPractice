#include "myheader.h"

void pri_search(struct node *rear,int info)
{
	struct node *nodeptr = NULL;
	int count = 0;
	if(rear == NULL){
		printf("Empty list\n");
		return;
	}


	nodeptr = rear;
	while(nodeptr->link != rear){
		count++;
		nodeptr = nodeptr->link;
		if(nodeptr->data == info){
			printf("data is at %d position\n",count);
			return;
		}
	}
	count++;
	nodeptr = nodeptr->link;
	if(nodeptr->data == info){
         printf("data is at %d position\n",count);
         return;
    }

	printf("%d is not found in the que\n",info);
	return;
}
