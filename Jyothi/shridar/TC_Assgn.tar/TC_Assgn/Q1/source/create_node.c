#include "myheader.h"

struct node * create_node(int pri,int info)
{
	struct node *nodeptr = NULL;

	if(NULL == (nodeptr = (struct node *)malloc(sizeof(struct node)))){
		printf("malloc error\n");
		exit(0);
	}
	else{
		nodeptr -> prio = pri;
		nodeptr -> data = info;
		nodeptr -> link = NULL;
	}
	return nodeptr;
}
