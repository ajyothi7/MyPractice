#include <myheader.h>

int main(void)
{
char *buf = NULL;
struct node *rear = NULL;
//struct node *front = NULL;
int prio = 0;
int data = 0;
if(NULL == (buf = (char *)malloc(sizeof(char) * MAX)))
	{
		perror("i/p failed\n");
        exit(EXIT_FAILURE);
	}

int choice;

while(1)
{
	printf("enter the choice\n"
			"1.ENQ\n"
			"2.DEQ\n"
			"3.display\n"
			"4.search\n"
			"5.terminate\n"
			"0.exit\n");
	
	if(NULL == fgets(buf,MAX,stdin))
    {
        perror("i/p failed\n");
        exit(EXIT_FAILURE);
	}

	choice = my_atoi(buf);
    
	switch(choice){
		case 0 :	exit(0);
		case 1 : 	printf("enter the item to push\n");
		
					 if(NULL == fgets(buf,MAX,stdin)){
        				perror("i/p failed\n");
        				exit(EXIT_FAILURE);
    				}

					data = my_atoi(buf);

					printf("enter the priority\n");

					if(NULL == fgets(buf,MAX,stdin)){
                        perror("i/p failed\n");
                        exit(EXIT_FAILURE);
                    }
					prio = my_atoi(buf);

					rear = pri_insert(rear,prio,data);
					sort_que(rear);
					break;
		case 2:
				rear = pri_delete(rear);
				break;
		case 3 :pri_display(rear);
				break;
		case 4 :printf("Enter the data to be searched\n");
                if(NULL == fgets(buf,MAX,stdin)){
					perror("i/p failed\n");
                    exit(EXIT_FAILURE);
                }
                data = my_atoi(buf);
				
				pri_search(rear,data);
				
				break;

		case 5 :rear = pri_terminate(rear);
				printf("Que terminated succesfully\n");
				break;

		default :printf("Enter the right choice\n");
				break;
	}
}
}
