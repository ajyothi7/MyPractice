#include "header.h"
#include "Book.h"

float Book :: totalCost(int noOfCopies)
{
	return noOfCopies * price;
}
