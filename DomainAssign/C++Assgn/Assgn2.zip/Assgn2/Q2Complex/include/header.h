#ifndef __HEADER__
	#define __HEADER__ 1

	#include <iostream>
	#include <stdlib.h>
	#include <limits.h>
	#include <stdio.h>
	#include <string.h>
	#include <math.h>

	#define MAX 256

	using namespace std;

	float read_input(void);
	double my_atof(char input[]);
#endif
