#include "header.h"
#include "Teacher.h"

void Teacher :: gradeStudent(void)
{
	cout << "student graded" << endl;
} 
