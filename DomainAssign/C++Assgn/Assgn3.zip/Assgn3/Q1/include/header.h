#ifndef __HEADER__
	#define __HEADER__ 1

	#include <iostream>
	#include <stdlib.h>
	#include <limits.h>
	#include <stdio.h>
	#include <string.h>
	#include <math.h>
	
	#define MAX 256
	#define ZERO 0
	#define ONE 1

	using namespace std;

	char *read_input(char *input);
	double my_atoi(char input[]);
	double my_atof(char input[]);
#endif
