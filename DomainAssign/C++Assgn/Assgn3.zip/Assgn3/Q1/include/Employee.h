#include "header.h"

class Employee
{
	private:
		char *empNum;
		char *empName;
		char *empDesig;

	public:
		Employee(){
			empName = NULL;
			empNum = NULL;
			empDesig = NULL;
		}

		~Employee(){
			empName = NULL;
			empNum = NULL;
			empDesig = NULL;
		}

		void setEmpNum(char *empNum);
		void setEmpName(char *empName);
		void setEmpDesig(char *empDesig);

		char* getEmpNum(void);
		char* getEmpName(void);
		char* getEmpDesig(void);
	
		void getEmployeeInfo(void);
};
