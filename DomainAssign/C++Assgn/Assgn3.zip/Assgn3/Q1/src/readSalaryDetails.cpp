#include "header.h"
#include "Salary.h"

bool readSalaryDetails(Salary *sal)
{
	char *input = NULL;

	try{
		if(NULL == (input = (char*)malloc(sizeof(char *) * MAX))){
			throw "malloc() failed";
		}

		cout << "enter basic salary: " ;
		input = read_input(input);	
		sal -> setBasicPay(my_atof(input));
	
		cout << "enter HRA: " ;
		input = read_input(input);	
		sal -> setHRA(my_atof(input));
	
		cout << "enter DA: " ;
		input = read_input(input);	
		sal -> setDA(my_atof(input));

		cout << "enter PF: " ;
		input = read_input(input);	
		sal -> setPF(my_atof(input));
	}

	catch(const char *msg)
	{
		free(input);
		input = NULL;

		throw msg; 
	}

	free(input);
	input = NULL;

	return true;
}
