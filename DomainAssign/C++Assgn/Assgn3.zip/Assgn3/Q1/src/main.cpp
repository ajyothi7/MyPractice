#include "header.h"
#include "Salary.h"

bool readEmpDetails(Salary *);
bool readSalaryDetails(Salary *);

int main(void)
{
	char *input = NULL;
	int noOfEmp;
//	Salary s[MAX];
		
	try{
		if(NULL == (input = (char *) malloc(sizeof(int) * MAX))){
            throw "malloc() failed";
        }	

		cout << "enter no of employees:" << endl;
		input = read_input(input);
		noOfEmp = my_atoi(input);

		Salary s[noOfEmp];

		if(noOfEmp < ONE){
			cout << "cannot read " << noOfEmp << " details" << endl;
			cout << "out of range" << endl;

			return EXIT_FAILURE;
		}

		for(int index = ZERO; index < noOfEmp; index++){
			
			cout << "enter employee" << index + ONE<< " details" << endl;
			readEmpDetails(&s[index]);

			cout << "enter " << s[index].getEmpName() << "'s salary details" << endl;
			readSalaryDetails(&s[index]);
		}

		cout << "*********************************" << endl;
		cout << "employee details:" << endl;
		for(int index = ZERO; index < noOfEmp; index++){
			s[index].display();
		}		
	}	

	catch(const char *msg)
	{
		cout << msg << endl;
	}

	free(input);
	input = NULL;

	return EXIT_SUCCESS;
}
