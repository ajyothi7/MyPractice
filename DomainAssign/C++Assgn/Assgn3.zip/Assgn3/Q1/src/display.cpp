#include "header.h"
#include "Salary.h"

void Salary :: display(void)
{
	this -> getEmployeeInfo();
	this -> getSalaryInfo();
}
