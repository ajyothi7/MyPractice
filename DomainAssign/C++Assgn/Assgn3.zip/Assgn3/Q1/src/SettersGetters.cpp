#include "header.h"
#include "Salary.h"

void Employee :: setEmpNum(char *empNum)
{
	this -> empNum = empNum;
}

void Employee :: setEmpName(char *empName)
{
	this -> empName = empName;
}

void Employee :: setEmpDesig(char *empDesig)
{
	this -> empDesig = empDesig;
}

char* Employee :: getEmpNum(void)
{
	return this -> empNum;
}

char* Employee :: getEmpName(void)
{
	return this -> empName;
}

char* Employee :: getEmpDesig(void)
{
	return this -> empDesig;
}

void Salary :: setBasicPay(float basicPay)
{
	this -> basicPay = basicPay;
}

void Salary :: setHRA(float hra)
{
	this -> hra = hra;
}

void Salary :: setDA(float da)
{
	this -> da = da;
}

void Salary :: setPF(float pf)
{
	this -> pf = pf;
}

float Salary :: getBasicPay(void)
{
	return this -> basicPay;
}

float Salary :: getHRA(void)
{
	return this -> hra;
}

float Salary :: getDA(void)
{
	return this -> da;
}

float Salary :: getPF(void)
{
	return this -> pf;
}
