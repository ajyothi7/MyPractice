#include "header.h"
#include "Salary.h"

bool readEmpDetails(Salary *sal)
{
	char *input = NULL;

	try{
		if(NULL == (input = (char*)malloc(sizeof(char *) * MAX))){
			throw "malloc() failed";
		}

		cout << "enter employee num: " ;
		input = read_input(input);	
		if((input == NULL) || (*input == '\0')){
			throw "invalid input";
		}
		sal -> setEmpNum(input);
	
		cout << "enter employee name: " ;
		input = read_input(input);	
		if((input == NULL) || (*input == '\0')){
			throw "invalid input";
		}
		sal -> setEmpName(input);
	
		cout << "enter employee designation: " ;
		input = read_input(input);	
		if((input == NULL) || (*input == '\0')){
			throw "invalid input";
		}
		sal -> setEmpDesig(input);
	}

	catch(const char *msg)
	{
		free(input);
		input = NULL;

		throw msg; 
	}

	free(input);
	input = NULL;

	return true;
}
